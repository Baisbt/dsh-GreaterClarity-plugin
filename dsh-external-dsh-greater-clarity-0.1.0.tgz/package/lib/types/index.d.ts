/**
 * dsh-greater-clarity —— Host 半：webServer 路由 + 设置持久化 + Markdown 导出。
 *
 * 路由（全部挂 ctx.effect，卸载即净）：
 *   GET  /dsh-greater-clarity/avatar          → 头像图片字节
 *   GET  /dsh-greater-clarity/settings        → 读设置
 *   POST /dsh-greater-clarity/settings        → 写设置（部分 patch）
 *   POST /dsh-greater-clarity/avatar-upload   → 上传头像（dataUrl base64 落盘）
 *   POST /dsh-greater-clarity/export          → { sessionId } → { ok, markdown, filename }
 *
 * 设置持久化在 $DSH_HOME/greater-clarity/settings.json（自建文件，
 * 不依赖 DSH settings provider 是否挂载，与 whale-widget/super-injector 先例一致）。
 */
import type { Context } from 'cordis';
interface RouteOpts {
    kind: 'exact' | 'prefix';
    path: string;
    handler: (req: any, res: any) => void;
}
interface WebServerLike {
    register(opts: RouteOpts): () => void;
}
type AppContext = Context & {
    webServer: WebServerLike;
};
export declare const name = "dsh-greater-clarity";
export declare const inject: string[];
export declare function apply(ctx: AppContext): void;
export {};
